setwd("C:\\Users\\IT24100688\\Documents\\IT24100688_Lab_04")

branch_data<-read.table("Exercise.txt",header = TRUE, sep=",")

fix(branch_data)

attach(branch_data)


boxplot(Sales_X1,main="Branch sales",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(Advertising_X2,main="Advertising",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(Years_X3,main="Salary",outline=TRUE,outpch=8,horizontal=TRUE)


summary(Advertising_X2)
IQR(Advertising_X2)
